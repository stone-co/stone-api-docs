from jwcrypto import jwk, jwe
from jwcrypto.common import json_encode
import time
import requests
import subprocess
import simplejson as json
from environment import getToken
from get_public_key import getPublicKey
from get_public_key import extractPublicKeyHeader
from environment import getApplicationData

def signUp(access_token):

  app_data = getApplicationData()
  auth_url = f'{app_data.base_url}/applications/application:{app_data.client_id}/signups'

  headers = {
    'Content-Type': 'application/json',
    'Authorization': f'Bearer {access_token}'
  }

  # INFORMAÇÕES DO USER PRA QUAL DESEJA ABRIR CONTA
  payload = json_encode({
    'user': {
      'document': 'NUMERO DO DOCUMENTO',
      'document_type': 'CPF OU CNPJ',
      'full_name': 'NOME DA PESSOA',
      'email': 'EMAIL DA PESSOA'
    }
  })

  stone_public_key = getPublicKey()
  enc = extractPublicKeyHeader(stone_public_key)
  
  jwk_key = jwk.JWK(**stone_public_key)
  jwetoken = jwe.JWE(payload, enc)
  jwetoken.add_recipient(jwk_key)
  jwe_body = jwetoken.serialize(compact=True)

  body = {
    'jwe': jwe_body
  }

  json_body = json.dumps(body)

  return requests.post(auth_url, data=json_body, headers=headers)


response = getToken()
token = response.json()['access_token']

response = signUp(token)

print(f'Status Code: {response.status_code}')
print(f"x-request-id: {response.headers['x-request-id']}")
print(f'Response: {response.json()}')
