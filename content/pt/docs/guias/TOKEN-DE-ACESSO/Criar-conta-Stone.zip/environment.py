import jwt
import time
import requests
import subprocess

class AppData:
  def __init__(self, client_id, base_url, base_auth_url, private_key):
    self.client_id = client_id
    self.base_url = base_url
    self.base_auth_url = base_auth_url
    self.private_key = private_key


def getApplicationData():
    return AppData(
        'SEU CLIENT_ID',
        'https://sandbox-api.openbank.stone.com.br/api/v1',
        'https://sandbox-accounts.openbank.stone.com.br',
        private_key
    )

private_key = """-----BEGIN RSA PRIVATE KEY-----
SUA CHAVE PRIVADA
-----END RSA PRIVATE KEY-----
"""


def getToken():

    app_data = getApplicationData()

    base_url = f'{app_data.base_auth_url}/auth/realms/stone_bank'
    auth_url = f'{base_url}/protocol/openid-connect/token'

    payload = {
        'exp': int(time.time()) + 3600,
        'nbf': int(time.time()),
        'aud': base_url,
        'realm': 'stone_bank',
        'sub': app_data.client_id,
        'clientId': app_data.client_id,
        'jti': str(time.time()),
        'iat': int(time.time()),
        'iss': app_data.client_id
    }

    token = jwt.encode(payload, app_data.private_key, algorithm='RS256')

    headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'User-Agent': 'NOME-DA-SUA-APLICACAO'
    }

    token_payload = {
        'client_id': app_data.client_id,
        'grant_type': 'client_credentials',
        'client_assertion': token,
        'client_assertion_type': 'urn:ietf:params:oauth:client-assertion-type:jwt-bearer'
    }

    return requests.post(auth_url, data=token_payload, headers=headers)


# COMENTAR PRA NÃO COPIAR O TOKEN
response = getToken()
access_token = response.json()['access_token']
print (access_token)