import requests
from jwcrypto.common import json_encode
from environment import getApplicationData

def getPublicKey():

	app_data = getApplicationData()

	discovery_url = f'{app_data.base_url}/discovery/keys'

	response = requests.get(discovery_url)

	return list(filter(lambda x:x['use'] == 'enc', response.json()['keys']))[0]


def extractPublicKeyHeader(public_key):
  return json_encode({
  	'alg': 'RSA-OAEP-256',
  	'enc': 'A256GCM',
  	'kid': public_key['kid']
  })