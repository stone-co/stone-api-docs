const jwt = require('jsonwebtoken')
const { v4: uuidv4 } = require('uuid')

const client_id = 'seu client_id'
const accounts_url = 'https://sandbox.conta.stone.com.br'
const redirect_uri = 'sua url de redirect passada por formulario para o time de parcerias'

const private_key = `Sua chave privada`

const generateConsentLink = () => {
    const id = uuidv4()
    const payload = {
        type: 'consent',
        client_id: client_id,
        redirect_uri: redirect_uri,
        session_metadata: { sid: 'Stone Banking - SDB' },
        iss: client_id,
        aud: 'accounts-hubid@openbank.stone.com.br',
        jti: id,
    }

    console.log(payload)

    const token = jwt.sign(payload, private_key, { algorithm: 'RS256', expiresIn: '15m', notBefore: 0 })
    const url = `${accounts_url}/consentimento?client_id=${client_id}&jwt=${token}`

    return url
}

const link = generateConsentLink()

console.log('------------')
console.log('Link de Consentimento: ', link)
console.log('------------')